package com.example.camera;

public class NetworkSettings {
    public int id;
    public String Title;
    public String Address;
    public int Port;

    public String toString()
    {
        return String.valueOf(id) + " " + Title + " " + Address + ":" + Port;
    }
}
