package com.example.camera;

public class StaticDB {
    static DataBase database;
}
