package com.example.weather;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String KEY = "40b15f581e4e441fb4c62458211310";
    EditText txt;
    ListView loadlist;
    ArrayList<ListKey> lstNetwork = new ArrayList<>();
    ArrayAdapter<ListKey> adpNetwork;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = findViewById(R.id.textCity);
        StaticDB.database = new DB(this, "History", null, 1);
    }

    public void onClick(View v)
    {
        Intent intent = new Intent(this, Result.class);

        intent.putExtra("apikey", KEY);
        intent.putExtra("city", txt.getText().toString());

        startActivity(intent);
    }

    public void SelectKeyClick(View v)
    {
        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        View customLayout = getLayoutInflater().inflate(R.layout.dialog_settings, null);
        bld.setTitle("Settings");
        bld.setView(customLayout);

        EditText key = customLayout.findViewById(R.id.textKey);

        Button accept = customLayout.findViewById(R.id.btAcceptKey);
        Button cancel = customLayout.findViewById(R.id.btCancel);
        Button load = customLayout.findViewById(R.id.btLoad);
        Button save = customLayout.findViewById(R.id.btSave);
        Dialog dlg = bld.create();
        dlg.show();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //сохранить ключ
                int nid = StaticDB.database.getMaxIDForKey() + 1;
                StaticDB.database.addKey(nid, key.getText().toString());
                Toast.makeText(getApplicationContext(), "Settings save", Toast.LENGTH_LONG).show();
            }
        });
        load.setOnClickListener //загрузить ключи
                (view -> OnNetworkSettingsLoad(view, "Load", key));
        accept.setOnClickListener(view -> {
            KEY = String.valueOf(key.getText());
            dlg.cancel();
        });
        cancel.setOnClickListener(view -> dlg.cancel());
    }

    private void OnNetworkSettingsLoad(View view, String load, EditText key) { //загрузить ключи
        View customLayout = getLayoutInflater().inflate(R.layout.dialogload, null);
        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        bld.setTitle("Load keys");
        bld.setView(customLayout);
        Dialog dlg = bld.create();
        dlg.show();

        loadlist = customLayout.findViewById(R.id.list_keys);
        adpNetwork = new ArrayAdapter<ListKey>
                (this, android.R.layout.simple_list_item_1, lstNetwork);

        loadlist.setAdapter(adpNetwork);

        loadlist.setOnItemClickListener((parent, _view, position, id) -> {
            ListKey n = adpNetwork.getItem(position);
            key.setText(n.Key);
            dlg.cancel();
        });
        lstNetwork.clear();
        StaticDB.database.getAllKeys(lstNetwork);
        adpNetwork.notifyDataSetChanged();
    }



    public void HistoryClick(View v)
    {
        Intent intent = new Intent(this, ActivityList.class);
        startActivity(intent);
    }

}