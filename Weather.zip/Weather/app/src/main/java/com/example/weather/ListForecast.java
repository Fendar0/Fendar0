package com.example.weather;

public class ListForecast {
    public int id;
    public String city;
    public String date;
    public float temprature;
    public float feelslike;
    public float cloud;
    public float wind;
    public float pressure;
    public float precip;


    public String toString() {
        return id + "  " + date + "  " + city
                + "\nTemperature: " + temprature + " °C"
                + "\nFeelslike: "+ feelslike + " °C"
                + "\nWind: " + wind + " km/h"
                + "\nPressure: " + pressure + " millibars"
                + "\nPrecipitation: " + precip + " mm"
                + "\nCloud: " + cloud + " %";
    }
}