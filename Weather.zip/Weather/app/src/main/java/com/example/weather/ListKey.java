package com.example.weather;

public class ListKey {
    public int id;
    public String Key;

    public String toString()
    {
        return id + Key;
    }
}
