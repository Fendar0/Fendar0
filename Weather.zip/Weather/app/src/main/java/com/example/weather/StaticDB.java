package com.example.weather;

public class StaticDB {
    static DB database;
}
