package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ActivityList extends AppCompatActivity {

    ListView listView;
    ArrayList<ListForecast> listForecasts = new ArrayList<>();
    ArrayAdapter<ListForecast> adp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listView = findViewById(R.id.lstView);
        adp = new ArrayAdapter<ListForecast>(this, android.R.layout.simple_list_item_1, listForecasts);
        listView.setAdapter(adp);
        listForecasts.clear();
        StaticDB.database.getAllForecast(listForecasts);
        adp.notifyDataSetChanged();
    }

    public void CancelClick(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void deleteClick(View v)
    {
        StaticDB.database.deleteAll();
        listForecasts.clear();
        StaticDB.database.getAllForecast(listForecasts);
        adp.notifyDataSetChanged();
    }
}